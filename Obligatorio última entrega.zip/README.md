# eMercado - tu e-commerce favorito
**Workspace - Programación Aplicada (Módulo 2)**

Este proyecto trata sobre el Workspace desarrollado para las estudiantes de la generación 2019 de JAP - Jóvenes a Programar - Plan Ceibal.
No se trata de un e-commerce con datos verídicos y **todo su contenido es puramente ilustrativo**. Su contenido puede variar a futuro.

Puedes ingresar [aquí](https://jovenesaprogramar.edu.uy/) para saber más sobre Jóvenes a Programar.
